import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super(ConvBlock, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.SiLU()  # Using SiLU (Swish) activation

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

class CSPBlock(nn.Module):
    def __init__(self, in_channels, out_channels, num_repeats=1):
        super(CSPBlock, self).__init__()
        self.conv1 = ConvBlock(in_channels, out_channels // 2)
        self.conv2 = ConvBlock(out_channels // 2, out_channels // 2)
        self.conv3 = ConvBlock(out_channels, out_channels)
        self.residual_blocks = nn.ModuleList([
            nn.Sequential(
                ConvBlock(out_channels // 2, out_channels // 2),
                ConvBlock(out_channels // 2, out_channels // 2)
            ) for _ in range(num_repeats)
        ])

    def forward(self, x):
        # Split input
        x1 = self.conv1(x)
        x2 = self.conv2(x1)
        
        # Apply residual blocks
        for block in self.residual_blocks:
            x2 = x2 + block(x2)
            
        # Concatenate and final conv
        x = torch.cat([x1, x2], dim=1)
        return self.conv3(x)

class YOLOv11(nn.Module):
    def __init__(self, num_classes, num_anchors=2, grid_size=7, input_size=(448, 448)):
        """
        YOLOv11 model implementation
        
        Args:
            num_classes (int): Number of classes to detect
            num_anchors (int): Number of anchor boxes per grid cell
            grid_size (int): Size of the detection grid
            input_size (tuple): Input image size (height, width)
        """
        super(YOLOv11, self).__init__()
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        self.grid_size = grid_size
        self.input_size = input_size
        
        # Calculate feature map sizes at each stage
        self.feature_sizes = []
        current_size = input_size
        for _ in range(5):  # 5 downsampling stages
            current_size = (current_size[0] // 2, current_size[1] // 2)
            self.feature_sizes.append(current_size)
        
        # Backbone with dynamic feature map sizes
        self.backbone = nn.Sequential(
            ConvBlock(3, 32),
            ConvBlock(32, 64, stride=2),  # First downsampling
            CSPBlock(64, 64),
            ConvBlock(64, 128, stride=2),  # Second downsampling
            CSPBlock(128, 128),
            ConvBlock(128, 256, stride=2),  # Third downsampling
            CSPBlock(256, 256),
            ConvBlock(256, 512, stride=2),  # Fourth downsampling
            CSPBlock(512, 512),
            ConvBlock(512, 1024, stride=2),  # Fifth downsampling
            CSPBlock(1024, 1024)
        )
        
        # Feature Pyramid Network (FPN)
        self.fpn = nn.ModuleList([
            nn.Sequential(
                ConvBlock(1024, 512),
                ConvBlock(512, 256)
            ),
            nn.Sequential(
                ConvBlock(512, 256),
                ConvBlock(256, 128)
            ),
            nn.Sequential(
                ConvBlock(256, 128),
                ConvBlock(128, 64)
            )
        ])
        
        # Detection heads for different scales
        self.detection_heads = nn.ModuleList([
            nn.Conv2d(256, num_anchors * 5 + num_classes, kernel_size=1),  # Large objects
            nn.Conv2d(128, num_anchors * 5 + num_classes, kernel_size=1),  # Medium objects
            nn.Conv2d(64, num_anchors * 5 + num_classes, kernel_size=1)    # Small objects
        ])
        
        # Upsampling layers
        self.upsample = nn.Upsample(scale_factor=2, mode='nearest')
        
    def forward(self, x):
        """
        Forward pass of the model
        
        Args:
            x (torch.Tensor): Input images [batch_size, 3, height, width]
            
        Returns:
            list: List of detection predictions at different scales
        """
        # Backbone feature extraction
        features = []
        for i, layer in enumerate(self.backbone):
            x = layer(x)
            if isinstance(layer, ConvBlock) and layer.conv.stride[0] == 2:
                features.append(x)
        
        # FPN feature fusion
        fpn_features = []
        for i, fpn_layer in enumerate(self.fpn):
            if i == 0:
                fpn_features.append(fpn_layer(features[-1]))
            else:
                upsampled = self.upsample(fpn_features[-1])
                concat = torch.cat([upsampled, features[-(i+1)]], dim=1)
                fpn_features.append(fpn_layer(concat))
        
        # Detection heads
        predictions = []
        for i, (feature, head) in enumerate(zip(fpn_features, self.detection_heads)):
            pred = head(feature)
            batch_size = pred.shape[0]
            grid_h, grid_w = pred.shape[2:]
            
            # Reshape predictions to match YOLO format
            pred = pred.permute(0, 2, 3, 1)  # [batch_size, grid_h, grid_w, num_anchors * 5 + num_classes]
            predictions.append(pred)
        
        return predictions 