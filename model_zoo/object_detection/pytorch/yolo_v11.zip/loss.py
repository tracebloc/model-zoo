import torch
import torch.nn as nn
import torch.nn.functional as F

class YOLOLoss(nn.Module):
    def __init__(self, lambda_coord=5.0, lambda_noobj=0.5, lambda_obj=1.0, lambda_class=1.0):
        """
        YOLO Loss function implementation
        
        Args:
            lambda_coord (float): Weight for coordinate loss
            lambda_noobj (float): Weight for no-object confidence loss
            lambda_obj (float): Weight for object confidence loss
            lambda_class (float): Weight for classification loss
        """
        super(YOLOLoss, self).__init__()
        self.lambda_coord = lambda_coord
        self.lambda_noobj = lambda_noobj
        self.lambda_obj = lambda_obj
        self.lambda_class = lambda_class
        
    def forward(self, predictions, targets):
        """
        Forward pass of the loss function
        
        Args:
            predictions (torch.Tensor): Model predictions [batch_size, grid_size, grid_size, num_anchors * 5 + num_classes]
            targets (torch.Tensor): Ground truth targets [batch_size, grid_size, grid_size, num_anchors * 5 + num_classes]
            
        Returns:
            torch.Tensor: Total loss value
        """
        batch_size = predictions.shape[0]
        
        # Split predictions into components
        pred_xy = predictions[..., :2]  # x, y coordinates
        pred_wh = predictions[..., 2:4]  # width, height
        pred_conf = predictions[..., 4]  # confidence
        pred_cls = predictions[..., 5:]  # class predictions
        
        # Split targets into components
        target_xy = targets[..., :2]
        target_wh = targets[..., 2:4]
        target_conf = targets[..., 4]
        target_cls = targets[..., 5:]
        
        # Create object mask
        obj_mask = target_conf > 0
        noobj_mask = ~obj_mask
        
        # Coordinate loss (x, y)
        xy_loss = self.lambda_coord * torch.sum(
            obj_mask * torch.sum((pred_xy - target_xy) ** 2, dim=-1)
        )
        
        # Width and height loss
        wh_loss = self.lambda_coord * torch.sum(
            obj_mask * torch.sum((torch.sqrt(pred_wh) - torch.sqrt(target_wh)) ** 2, dim=-1)
        )
        
        # Object confidence loss
        obj_conf_loss = self.lambda_obj * torch.sum(
            obj_mask * (pred_conf - target_conf) ** 2
        )
        
        # No-object confidence loss
        noobj_conf_loss = self.lambda_noobj * torch.sum(
            noobj_mask * (pred_conf - target_conf) ** 2
        )
        
        # Classification loss
        cls_loss = self.lambda_class * torch.sum(
            obj_mask * torch.sum((pred_cls - target_cls) ** 2, dim=-1)
        )
        
        # Total loss
        total_loss = (xy_loss + wh_loss + obj_conf_loss + noobj_conf_loss + cls_loss) / batch_size
        
        return total_loss 